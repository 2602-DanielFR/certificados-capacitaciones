@extends('layouts.public')
@section('title', 'Estado de certificado | Capacita+')
@section('content')
<div class="mx-auto bg-white border rounded-4 p-4 p-lg-5" style="max-width:760px">
    <div class="small text-primary text-uppercase fw-bold mb-2">Consulta de certificado</div>
    <h1 class="h2 fw-bold mb-1">{{ $registration->course->title }}</h1>
    <p class="muted mb-4">Participante: {{ $registration->full_name }}</p>
    <div class="border rounded-3 p-3 mb-4 d-flex justify-content-between gap-3 align-items-center"><span class="muted">Estado</span>
        @if ($registration->status === 'attended') <span class="badge text-bg-success fs-6">Asistencia confirmada</span>
        @elseif ($registration->status === 'absent') <span class="badge text-bg-danger fs-6">No asistió</span>
        @else <span class="badge text-bg-warning fs-6">Pendiente de validación</span> @endif
    </div>
    @if ($registration->status === 'attended')
        <p>Tu participación ha sido validada. El certificado está listo para descargar.</p>
        <a class="btn btn-primary btn-lg" href="{{ route('certificates.download', $registration->certificate_code) }}">Descargar certificado PDF</a>
    @elseif ($registration->status === 'absent')
        <p>El administrador ha registrado que no asististe a esta capacitación. No hay un certificado disponible para esta inscripción.</p>
    @else
        <p>Tu inscripción está registrada. El certificado estará disponible cuando el administrador confirme que participaste en la capacitación.</p>
    @endif
    <hr class="my-4"><div class="small muted">Código de consulta: <span class="font-monospace">{{ $registration->certificate_code }}</span></div>
    <a href="{{ route('home') }}" class="btn btn-outline-secondary mt-3">Volver a capacitaciones</a>
</div>
@endsection
