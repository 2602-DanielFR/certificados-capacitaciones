<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 18px; }
        body { font-family: DejaVu Sans, sans-serif; color:#172b4d; margin:0; }
        .frame { border:4px solid #183f78; padding:26px; height:495px; text-align:center; position:relative; }
        .inner { border:1px solid #c7a65a; padding:30px 25px; height:425px; }
        .brand { color:#245cb9; font-size:13px; font-weight:bold; letter-spacing:3px; text-transform:uppercase; }
        .title { color:#17365f; font-size:34px; font-weight:bold; margin:18px 0 8px; }
        .subtitle { font-size:17px; margin-bottom:20px; }
        .name { color:#1c4f9c; font-size:30px; font-weight:bold; border-bottom:1px solid #b6c5d7; padding:7px 0 14px; margin:0 auto 15px; width:82%; }
        .course { font-size:21px; font-weight:bold; margin:14px auto; width:82%; }
        .detail { color:#55657b; font-size:12px; line-height:1.8; }
        .code { position:absolute; bottom:16px; right:23px; font-size:9px; color:#66758b; }
        .signature { display:inline-block; border-top:1px solid #8392a6; padding-top:7px; width:210px; margin-top:30px; font-size:11px; }
    </style>
</head>
<body>
<div class="frame"><div class="inner">
    <div class="brand">Institución organizadora</div>
    <div class="title">CERTIFICADO DE PARTICIPACIÓN</div>
    <div class="subtitle">Se otorga el presente certificado a:</div>
    <div class="name">{{ $registration->full_name }}</div>
    <div class="detail">Por haber participado satisfactoriamente en la capacitación</div>
    <div class="course">{{ $registration->course->title }}</div>
    <div class="detail">
        Realizada el {{ $registration->course->start_at->translatedFormat('d \\d\\e F \\d\\e Y') }}.
        Duración: {{ $registration->course->hours }} hora(s).
        @if($registration->course->instructor) Ponente: {{ $registration->course->instructor }}. @endif
    </div>
    <div class="signature">Firma de la persona responsable</div>
    <div class="code">Código de verificación: {{ $registration->certificate_code }}</div>
</div></div>
</body>
</html>
