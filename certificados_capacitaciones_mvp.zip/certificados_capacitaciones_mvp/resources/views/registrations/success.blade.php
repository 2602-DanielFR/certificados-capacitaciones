@extends('layouts.public')
@section('title', 'Inscripción registrada | Capacita+')
@section('content')
<div class="mx-auto text-center bg-white border rounded-4 p-4 p-lg-5" style="max-width:760px">
    <div class="rounded-circle bg-success-subtle text-success d-inline-flex align-items-center justify-content-center mb-4" style="width:72px;height:72px;font-size:2rem">✓</div>
    <div class="text-success fw-bold small text-uppercase mb-2">Inscripción registrada</div>
    <h1 class="h2 fw-bold">¡Gracias, {{ $registration->full_name }}!</h1>
    <p class="muted">Tu inscripción a <strong>{{ $registration->course->title }}</strong> se registró correctamente. Guarda tu código para consultar el estado de tu certificado.</p>
    <div class="my-4 p-3 rounded-3" style="background:#f2f6ff"><div class="small muted mb-1">Tu código de consulta</div><div class="font-monospace fs-3 fw-bold" id="registrationCode">{{ $registration->certificate_code }}</div><button class="btn btn-sm btn-outline-primary mt-2" onclick="navigator.clipboard.writeText('{{ $registration->certificate_code }}').then(()=>this.textContent='Copiado')">Copiar código</button></div>
    <a class="btn btn-primary" href="{{ route('certificates.show', $registration->certificate_code) }}">Consultar estado</a>
    <a class="btn btn-outline-secondary" href="{{ route('home') }}">Volver al inicio</a>
</div>
@endsection
