@extends('layouts.public')
@section('title', $course->title . ' | Capacita+')
@section('content')
<a href="{{ route('home') }}" class="text-decoration-none">← Volver a capacitaciones</a>
<div class="row g-4 mt-1">
    <div class="col-lg-7"><div class="bg-white border rounded-4 p-4 p-lg-5">
        <span class="badge text-bg-primary mb-3">{{ ucfirst($course->modality) }}</span>
        <h1 class="display-6 fw-bold">{{ $course->title }}</h1>
        <p class="lead muted">{{ $course->summary }}</p>
        <hr class="my-4">
        <div class="row g-3 mb-4">
            <div class="col-sm-6"><div class="small muted">Fecha de inicio</div><div class="fw-semibold">{{ $course->start_at->translatedFormat('d \\d\\e F \\d\\e Y, H:i') }}</div></div>
            <div class="col-sm-6"><div class="small muted">Duración</div><div class="fw-semibold">{{ $course->hours }} hora(s)</div></div>
            <div class="col-sm-6"><div class="small muted">Ponente</div><div class="fw-semibold">{{ $course->instructor ?: 'Por confirmar' }}</div></div>
            <div class="col-sm-6"><div class="small muted">Lugar / enlace</div><div class="fw-semibold">{{ $course->location ?: 'Se informará al participante' }}</div></div>
        </div>
        <h2 class="h5 fw-bold">Sobre la capacitación</h2>
        <div class="text-secondary">{!! nl2br(e($course->description ?: 'Información detallada próximamente.')) !!}</div>
    </div></div>
    <div class="col-lg-5"><div id="inscripcion" class="bg-white border rounded-4 p-4 p-lg-5 sticky-top" style="top:100px">
        <h2 class="h4 fw-bold">Inscríbete gratis</h2><p class="muted">Completa tus datos tal como deben aparecer en el certificado.</p>
        @if ($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
        <form method="POST" action="{{ route('registrations.store', $course) }}" class="vstack gap-3">
            @csrf
            <div><label class="form-label">Nombres y apellidos *</label><input name="full_name" class="form-control" required maxlength="180" value="{{ old('full_name') }}"></div>
            <div class="row g-2"><div class="col-5"><label class="form-label">Documento *</label><select class="form-select" name="document_type" required><option value="DNI">DNI</option><option value="CE" @selected(old('document_type')==='CE')>CE</option><option value="PASAPORTE" @selected(old('document_type')==='PASAPORTE')>Pasaporte</option><option value="OTRO" @selected(old('document_type')==='OTRO')>Otro</option></select></div><div class="col-7"><label class="form-label">Número *</label><input name="document_number" class="form-control" required maxlength="25" value="{{ old('document_number') }}"></div></div>
            <div><label class="form-label">Correo electrónico *</label><input type="email" name="email" class="form-control" required maxlength="190" value="{{ old('email') }}"></div>
            <div><label class="form-label">Teléfono</label><input name="phone" class="form-control" maxlength="30" value="{{ old('phone') }}"></div>
            <div><label class="form-label">Institución</label><input name="institution" class="form-control" maxlength="190" value="{{ old('institution') }}"></div>
            <div class="form-text">Al inscribirte recibirás un código para consultar el estado de tu certificado. La descarga se habilita cuando se confirma tu asistencia.</div>
            <button class="btn btn-primary btn-lg">Confirmar inscripción</button>
        </form>
    </div></div>
</div>
@endsection
