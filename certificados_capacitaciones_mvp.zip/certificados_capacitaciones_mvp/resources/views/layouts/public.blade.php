<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Capacitaciones y Certificados')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --ink:#12243a; --blue:#185adb; --pale:#f3f7ff; --muted:#65758b; }
        body { background:#f7f9fc; color:var(--ink); }
        .navbar { background:white; border-bottom:1px solid #e6ebf2; }
        .brand-dot { display:inline-block;width:12px;height:12px;border-radius:4px;background:var(--blue);margin-right:9px; }
        .hero { background:linear-gradient(130deg,#10294a 0%,#185adb 70%,#4086ff 100%); color:white; border-radius:28px; padding:clamp(30px,5vw,68px); }
        .eyebrow { text-transform:uppercase; letter-spacing:.13em; font-size:.76rem; font-weight:800; color:#9dbbff; }
        .btn-primary { background:var(--blue); border-color:var(--blue); }
        .course-card { border:1px solid #e7ecf3; border-radius:18px; transition:transform .18s,box-shadow .18s; height:100%; }
        .course-card:hover { transform:translateY(-3px); box-shadow:0 15px 35px rgba(27,57,98,.09); }
        .course-icon { display:grid;place-items:center;width:48px;height:48px;border-radius:14px;background:#eaf1ff;color:var(--blue);font-size:1.2rem;font-weight:800; }
        .muted { color:var(--muted); }
        .footer { border-top:1px solid #e6ebf2;background:white; }
        .form-control,.form-select { border-color:#d9e1ec;padding:.7rem .85rem; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container py-2">
        <a class="navbar-brand fw-bold" href="{{ route('home') }}"><span class="brand-dot"></span>Capacita<span class="text-primary">+</span></a>
        <div class="ms-auto d-flex gap-2">
            <a class="btn btn-outline-primary btn-sm" href="{{ route('home') }}#capacitaciones">Ver capacitaciones</a>
            <a class="btn btn-primary btn-sm" href="{{ url('/admin') }}">Administración</a>
        </div>
    </div>
</nav>
<main class="container py-4 py-lg-5">
    @if (session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
    @yield('content')
</main>
<footer class="footer mt-5 py-4"><div class="container d-flex flex-column flex-md-row justify-content-between gap-2"><span class="fw-semibold">Capacita+</span><span class="muted small">Formación, participación y certificación digital.</span></div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
