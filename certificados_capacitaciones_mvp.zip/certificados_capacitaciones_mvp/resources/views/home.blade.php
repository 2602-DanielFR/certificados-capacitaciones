@extends('layouts.public')
@section('title', 'Capacitaciones disponibles | Capacita+')
@section('content')
<section class="hero mb-5">
    <div class="row align-items-center g-4">
        <div class="col-lg-8">
            <div class="eyebrow mb-3">Aprende · participa · certifica</div>
            <h1 class="display-5 fw-bold mb-3">Impulsa tus conocimientos con nuestras capacitaciones.</h1>
            <p class="lead text-white-50 mb-4">Encuentra una capacitación, inscríbete en línea y consulta tu certificado digital cuando tu participación haya sido validada.</p>
            <a class="btn btn-light btn-lg fw-semibold" href="#capacitaciones">Explorar capacitaciones <span aria-hidden="true">→</span></a>
        </div>
        <div class="col-lg-4 d-none d-lg-block"><div class="p-4 rounded-4" style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18)"><div class="fs-1 mb-3">✦</div><h2 class="h4 fw-bold">Un solo lugar</h2><p class="mb-0 text-white-50">Inscripción y certificados en formato digital, disponibles desde cualquier dispositivo.</p></div></div>
    </div>
</section>
<section id="capacitaciones">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-2 mb-4">
        <div><div class="text-primary fw-bold small text-uppercase mb-2">Próximas actividades</div><h2 class="fw-bold mb-1">Capacitaciones disponibles</h2><p class="muted mb-0">Selecciona una actividad para revisar los detalles e inscribirte.</p></div>
        <span class="badge rounded-pill text-bg-light border px-3 py-2">{{ $courses->total() }} capacitaciones</span>
    </div>
    <div class="row g-4">
        @forelse($courses as $course)
            <div class="col-md-6 col-lg-4"><article class="card course-card shadow-sm"><div class="card-body p-4 d-flex flex-column">
                <div class="course-icon mb-3">{{ mb_strtoupper(mb_substr($course->title, 0, 1)) }}</div>
                <div class="small muted mb-2">{{ $course->start_at->translatedFormat('d M Y · H:i') }}</div>
                <h3 class="h5 fw-bold">{{ $course->title }}</h3>
                <p class="muted flex-grow-1">{{ $course->summary ?: \Illuminate\Support\Str::limit(strip_tags($course->description), 135) }}</p>
                <div class="d-flex justify-content-between align-items-center mb-3"><span class="badge text-bg-light border">{{ ucfirst($course->modality) }}</span><small class="muted">{{ $course->hours }} hora(s)</small></div>
                <a class="btn btn-outline-primary w-100" href="{{ route('courses.show', $course) }}">Ver capacitación</a>
            </div></article></div>
        @empty
            <div class="col-12"><div class="bg-white border rounded-4 text-center p-5"><div class="fs-1 mb-3">📚</div><h3 class="h5">Próximamente anunciaremos nuevas capacitaciones</h3><p class="muted mb-0">Vuelve a consultar esta página más adelante.</p></div></div>
        @endforelse
    </div>
    <div class="mt-4">{{ $courses->links('pagination::bootstrap-5') }}</div>
</section>
<section class="mt-5 p-4 p-lg-5 rounded-4 bg-white border d-md-flex justify-content-between align-items-center gap-4"><div><h2 class="h4 fw-bold">¿Ya participaste en una capacitación?</h2><p class="muted mb-md-0">Ingresa el código que recibiste al inscribirte para consultar el estado de tu certificado.</p></div><a href="#consultar" class="btn btn-dark mt-3 mt-md-0" data-bs-toggle="collapse" data-bs-target="#certificateLookup">Consultar certificado</a></section>
<div id="certificateLookup" class="collapse mt-3"><div class="card card-body"><form onsubmit="event.preventDefault(); const c=document.getElementById('certCode').value.trim(); if(c) window.location='{{ url('/certificados') }}/'+encodeURIComponent(c);" class="row g-2"><div class="col-md-9"><label for="certCode" class="form-label">Código de inscripción/certificado</label><input id="certCode" class="form-control" required placeholder="Ej. A1B2C3D4E5F6"></div><div class="col-md-3 d-flex align-items-end"><button class="btn btn-primary w-100">Consultar estado</button></div></form></div></div>
@endsection
