<?php

use App\Http\Controllers\CertificateController;
use App\Http\Controllers\PublicCourseController;
use App\Http\Controllers\RegistrationController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PublicCourseController::class, 'index'])->name('home');
Route::get('/capacitaciones/{course:slug}', [PublicCourseController::class, 'show'])->name('courses.show');
Route::post('/capacitaciones/{course:slug}/inscripcion', [RegistrationController::class, 'store'])->name('registrations.store');
Route::get('/certificados/{code}', [CertificateController::class, 'show'])->name('certificates.show');
Route::get('/certificados/{code}/descargar', [CertificateController::class, 'download'])->name('certificates.download');
