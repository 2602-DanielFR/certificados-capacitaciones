<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('registrations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained()->cascadeOnDelete();
            $table->string('full_name');
            $table->string('document_type', 10)->default('DNI');
            $table->string('document_number', 25);
            $table->string('email');
            $table->string('phone', 30)->nullable();
            $table->string('institution')->nullable();
            $table->string('status', 20)->default('registered'); // registered, attended, absent
            $table->string('certificate_code', 24)->unique();
            $table->timestamps();
            $table->unique(['course_id', 'document_type', 'document_number'], 'registrations_course_document_unique');
            $table->index(['course_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('registrations');
    }
};
