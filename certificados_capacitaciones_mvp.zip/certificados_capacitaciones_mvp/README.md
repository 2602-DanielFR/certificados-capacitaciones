# MVP: Sistema de capacitaciones y certificados (Laravel)

Este paquete contiene los archivos de base para agregar a una aplicación Laravel existente: catálogo público, inscripción, consulta del estado y descarga del certificado PDF cuando la asistencia está confirmada.

## Stack recomendado
- Laravel 13 (PHP 8.3+) o Laravel 12 si tu entorno aún no soporta PHP 8.3.
- Filament 5 para el panel administrativo `/admin`.
- MySQL/MariaDB.
- Bootstrap 5 para maquetar rápidamente las vistas públicas.
- `barryvdh/laravel-dompdf` para producir el certificado en PDF.

## Instalación rápida

> Recomendación: crear una aplicación separada llamada `certificados-capacitaciones`; no mezcles este proyecto con turismo-huanuco.

```powershell
composer create-project laravel/laravel certificados-capacitaciones
cd certificados-capacitaciones
composer require filament/filament:"~5.0"
php artisan filament:install --panels
composer require barryvdh/laravel-dompdf
```

En `.env`, configura tu base MySQL (crea primero la base de datos `certificados_capacitaciones`). Por ejemplo:

```env
APP_NAME="Capacitaciones y Certificados"
APP_URL=http://127.0.0.1:8000
APP_LOCALE=es
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=certificados_capacitaciones
DB_USERNAME=root
DB_PASSWORD=
```

Si usas Laravel Sail/Docker, usa el nombre del servicio MySQL como `DB_HOST` (normalmente `mysql`) y las credenciales que aparecen en tu `docker-compose.yml`; no copies los valores locales de arriba sin revisarlos.

## Copiar los archivos

Copia las carpetas `app`, `database`, `resources` y `routes` de este paquete dentro de la raíz de tu aplicación. Revisa los conflictos antes de reemplazar archivos existentes:

- Agrega las dos migraciones al directorio `database/migrations`.
- Agrega los modelos y controladores dentro de `app`.
- Agrega las vistas dentro de `resources/views`.
- **No reemplaces todo tu `routes/web.php` si ya contiene rutas propias**: incorpora las rutas del archivo de este paquete o haz una copia de seguridad antes.

Luego ejecuta:

```powershell
php artisan key:generate
php artisan migrate
php artisan make:filament-user
```

Sigue el asistente para crear el administrador. Luego crea los recursos del panel:

```powershell
php artisan make:filament-resource Course --generate
php artisan make:filament-resource Registration --generate
```

Abre `http://127.0.0.1:8000/admin` para administrar cursos e inscripciones. Para crear un curso visible al público, cambia su estado a `published`. En la tabla de cursos, el campo `status` debe ser `published` para mostrarlo públicamente (`draft` lo oculta). En la tabla de inscripciones, cambia `status` a `attended` únicamente cuando hayas validado que la persona participó. Los otros valores son `registered` y `absent`. Si el generador muestra estos campos como texto, escribe exactamente esos valores.

Inicia la aplicación (sin Sail):

```powershell
php artisan serve
```

En otra terminal, si el proyecto usa Vite:

```powershell
npm install
npm run dev
```

## Rutas principales

- `/` — catálogo de cursos publicados.
- `/capacitaciones/{slug}` — detalle e inscripción.
- `/certificados/{codigo}` — consulta del estado del certificado.
- `/certificados/{codigo}/descargar` — descarga PDF; solo funciona si `status = attended`.
- `/admin` — panel administrativo Filament.

## Importante antes de la entrega

1. Prueba una inscripción con datos ficticios.
2. Comprueba que el certificado no se descarga mientras el estado sea `registered`.
3. Desde el panel, cambia la inscripción a `attended` y verifica la descarga.
4. No habilites registros públicos de administrador.
5. Configura el nombre de la institución y el logotipo en `resources/views/certificates/pdf.blade.php`.
6. Para publicarlo en Internet, configura HTTPS, `APP_DEBUG=false`, copias de seguridad y un dominio. No uses `php artisan serve` como servidor de producción.

Este es un MVP para acelerar el desarrollo; antes de un uso institucional real agrega pruebas automatizadas, verificación de correo, política de privacidad y controles de acceso/registro de cambios.
