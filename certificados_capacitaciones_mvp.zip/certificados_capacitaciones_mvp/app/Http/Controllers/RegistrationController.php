<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Registration;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class RegistrationController extends Controller
{
    public function store(Request $request, Course $course): View|RedirectResponse
    {
        abort_unless($course->status === 'published', 404);

        $validated = $request->validate([
            'full_name' => ['required', 'string', 'min:5', 'max:180'],
            'document_type' => ['required', Rule::in(['DNI', 'CE', 'PASAPORTE', 'OTRO'])],
            'document_number' => ['required', 'string', 'max:25'],
            'email' => ['required', 'email:rfc', 'max:190'],
            'phone' => ['nullable', 'string', 'max:30'],
            'institution' => ['nullable', 'string', 'max:190'],
        ]);

        if ($course->capacity !== null && $course->registrations()->count() >= $course->capacity) {
            return back()->withErrors(['capacity' => 'Esta capacitación ya no tiene vacantes disponibles.'])
                ->withInput();
        }

        $alreadyRegistered = Registration::where('course_id', $course->id)
            ->where('document_type', $validated['document_type'])
            ->where('document_number', $validated['document_number'])
            ->exists();

        if ($alreadyRegistered) {
            return back()->withErrors(['document_number' => 'Ya existe una inscripción con este documento para esta capacitación.'])
                ->withInput();
        }

        do {
            $code = Str::upper(Str::random(12));
        } while (Registration::where('certificate_code', $code)->exists());

        $registration = Registration::create([
            ...$validated,
            'course_id' => $course->id,
            'status' => 'registered',
            'certificate_code' => $code,
        ]);

        return view('registrations.success', compact('registration'));
    }
}
