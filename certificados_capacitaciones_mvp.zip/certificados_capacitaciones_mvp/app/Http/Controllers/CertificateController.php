<?php

namespace App\Http\Controllers;

use App\Models\Registration;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Response;
use Illuminate\View\View;

class CertificateController extends Controller
{
    public function show(string $code): View
    {
        $registration = Registration::with('course')
            ->where('certificate_code', $code)
            ->firstOrFail();

        return view('certificates.show', compact('registration'));
    }

    public function download(string $code): Response
    {
        $registration = Registration::with('course')
            ->where('certificate_code', $code)
            ->firstOrFail();

        abort_unless($registration->status === 'attended', 403,
            'El certificado estará disponible después de que el administrador confirme tu asistencia.');

        $pdf = Pdf::loadView('certificates.pdf', compact('registration'))
            ->setPaper('a4', 'landscape');

        $filename = 'certificado-' . $registration->certificate_code . '.pdf';

        return $pdf->download($filename);
    }
}
