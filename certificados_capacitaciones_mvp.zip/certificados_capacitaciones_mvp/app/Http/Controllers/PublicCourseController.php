<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\View\View;

class PublicCourseController extends Controller
{
    public function index(): View
    {
        $courses = Course::published()->where('start_at', '>=', now()->startOfDay())
            ->orderBy('start_at')->paginate(9);

        return view('home', compact('courses'));
    }

    public function show(Course $course): View
    {
        abort_unless($course->status === 'published', 404);

        return view('courses.show', compact('course'));
    }
}
