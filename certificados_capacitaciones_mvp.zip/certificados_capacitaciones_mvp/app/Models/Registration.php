<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Registration extends Model
{
    use HasFactory;

    protected $fillable = [
        'course_id', 'full_name', 'document_type', 'document_number', 'email',
        'phone', 'institution', 'status', 'certificate_code',
    ];

    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    public function getAttendanceLabelAttribute(): string
    {
        return match ($this->status) {
            'attended' => 'Asistencia confirmada',
            'absent' => 'No asistió',
            default => 'Inscripción registrada',
        };
    }
}
